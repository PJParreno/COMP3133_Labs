# Assignment1-Full-Stack
Steps To Run Application
  1. NPM install - install dependencies need to run the application
  2. Nodemon - To start the server
  3. open LocalHost:4500
  
Group Members:
  Patrick Parreno - 101085299
  Asim Patel - 101162370
